//
//  YoutubeSearchResponse.swift
//  Netflix Clone
//
//  Created by Jose Luis Robles Barcenas on 08/12/2022.

import Foundation



struct YoutubeSearchResponse: Codable {
    let items: [VideoElement]
}


struct VideoElement: Codable {
    let id: IdVideoElement
}


struct IdVideoElement: Codable {
    let kind: String
    let videoId: String
}
