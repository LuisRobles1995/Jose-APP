//
//  TitleViewModel.swift
//  Netflix Clone
//
//  Created by Jose Luis Robles Barcenas on 08/12/2022.
//

import Foundation


struct TitleViewModel {
    let titleName: String
    let posterURL: String
}
