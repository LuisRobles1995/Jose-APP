//
//  TitlePreviewViewModel.swift
//  Netflix Clone
//
//  Created by Jose Luis Robles Barcenas on 08/12/2022.
//

import Foundation

struct TitlePreviewViewModel {
    let title: String
    let youtubeView: VideoElement
    let titleOverview: String
}
