//
//  Extensions.swift
//  Netflix Clone
//
//  Created by Jose luis Robles Barcenas 08/12/2022.
//

import Foundation


extension String {
    func capitalizeFirstLetter() -> String {
        return self.prefix(1).uppercased() + self.lowercased().dropFirst()
    }
}
